const int themeColor = 0xff756EF3;
const double screenPadding = 15; 
